package test;

public class _4 {
	public static void main(String[] args) {
		char[] c = new char[10];//1
		int[] arr = {0,1,2,3,4,5};
		char[] day = {'일','월','화','수','목','금','토'};
		boolean[] b = {true,false,false,true};
	}
}
