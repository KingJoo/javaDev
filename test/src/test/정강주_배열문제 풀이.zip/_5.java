package test;

public class _5 {
	public static void main(String[] args) {
		char[] alpha = {'a','b','c','d'};
		for(int i=0;i<alpha.length;i++)
			System.out.print(alpha[i]);
		//for(char c : alpha)	System.out.print(c);
	}
}
