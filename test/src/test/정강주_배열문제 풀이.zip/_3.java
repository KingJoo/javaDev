package test;

public class _3 {
	public static void main(String[] args) {
		//4번
	}
}
