package test;

public class _1 {
	//1. 아이디 중복 체크 
	static boolean isIdCheck(String id) {
		return true;
	}
	//2. 우편번호 검색
	static String[] postFind(String dong) {
		String[] s= {" "," "};
		return  s;
	}
	//3. 구구단 출력
	static void gugudan(int dan) {
		return;
	}
	
	public static void main(String[] args) {
		;
	}
}
